from typing import Literal


InetumGenerationModel = Literal[
    "inetum-gpt35turbo",
    "inetum-gpt4",
    "inetum-gpt4-turbo",
    "inetum-gpt4o",
]
