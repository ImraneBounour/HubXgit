import time
from typing import (
    Any,
    Callable,
    Dict,
    Iterator,
    List,
    Optional,
    Sequence,
    Union,
    Literal,
)
from langchain_core.messages import (
    BaseMessage,
    AIMessage,
    HumanMessage,
    ToolCall,
    ToolMessage,
    SystemMessage,
)
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.language_models import LanguageModelInput
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.tools import BaseTool
from langchain_core.utils.function_calling import convert_to_openai_tool
from langchain_core.runnables import Runnable
from langchain_core.language_models import BaseChatModel

from langchain_core.outputs import ChatGenerationChunk
from pydantic import SecretStr


from .config import DEFAULT_CONFIG
from .inetum_agent import InetumSDK
from .interfaces import InetumGenerationModel
from .utils.env import get_env_variable


class ChatInetum(BaseChatModel):
    """Inetum Chat Model.
    Inherits from BaseChatModel and implements the chat generation logic

    Attributes:
        model_name: The name of the model to use for generation.
        temperature: The temperature to use for generation.
        max_tokens: The maximum number of tokens to generate.
        timeout: The timeout for the generation request.
        stop: A list of strings on which the model should stop generating.
        max_retries: The maximum number of retries for the generation request.
    """

    inetum_api: Optional[InetumSDK] = None
    polling_interval: float = DEFAULT_CONFIG["polling_interval"]

    model_name: InetumGenerationModel = DEFAULT_CONFIG["model_name"]

    temperature: Optional[float] = None
    top_p: Optional[float] = None
    max_tokens: Optional[int] = None

    system_message: Optional[SystemMessage] = None

    stop: Optional[List[str]] = None

    timeout: int = DEFAULT_CONFIG["timeout"]
    max_retries: int = 2

    _tools: Optional[Sequence[BaseTool]] = None
    _formatted_tools: Optional[Sequence[dict[str, Any]]] = None
    _tool_choice: Optional[Union[dict, str, Literal["auto", "any"]]] = None

    def __init__(
        self,
        api_key: Optional[SecretStr] = None,
        api_url: Optional[str] = None,
        polling_interval: Optional[float] = None,
        model_name: InetumGenerationModel = DEFAULT_CONFIG["model_name"],
        temperature: Optional[float] = 0.16,
        max_tokens: Optional[int] = 16_000,
        top_p: Optional[float] = None,
        **kwargs: Any,
    ):
        super().__init__()

        if api_key is None:
            api_key = SecretStr(get_env_variable("INETUM_GENAI_API_KEY"))

        if api_url is None:
            api_url = DEFAULT_CONFIG["api_url"]

        # Custom model config
        self.model_name = model_name
        self.temperature = temperature
        self.top_p = top_p

        self.polling_interval = polling_interval or DEFAULT_CONFIG["polling_interval"]
        self.timeout = kwargs.get("timeout", DEFAULT_CONFIG["timeout"])

        self.max_tokens = max_tokens or DEFAULT_CONFIG["max_retries"]
        self.stop = kwargs.get("stop", None)

        self.inetum_api = InetumSDK(
            api_key=api_key,
            base_url=api_url,
            model=model_name,
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
        )

    def bind_tools(
        self,
        tools: Sequence[Union[dict[str, Any], type, Callable, BaseTool]],
        tool_choice: Optional[Union[dict, str, Literal["auto", "any"]]] = None,
        **kwargs: Any,
    ) -> Runnable[LanguageModelInput, BaseMessage]:
        """Bind tool-like objects to this chat model.

        Assumes model is compatible with OpenAI tool-calling API.

        Args:
            tools: A list of tool definitions to bind to this chat model.
                Supports any tool definition handled by
                :meth:`langchain_core.utils.function_calling.convert_to_openai_tool`.
            tool_choice: Which tool to require the model to call.
                Must be the name of the single provided function or
                "auto" to automatically determine which function to call
                (if any), or a dict of the form:
                {"type": "function", "function": {"name": <<tool_name>>}}.
            kwargs: Any additional parameters are passed directly to
                ``self.bind(**kwargs)``.
        """

        formatted_tools = [convert_to_openai_tool(tool) for tool in tools]
        if tool_choice:
            tool_names = []
            for tool in formatted_tools:
                if "function" in tool and (name := tool["function"].get("name")):
                    tool_names.append(name)
                elif name := tool.get("name"):
                    tool_names.append(name)
                else:
                    pass
            if tool_choice in tool_names:
                kwargs["tool_choice"] = {
                    "type": "function",
                    "function": {"name": tool_choice},
                }
            else:
                kwargs["tool_choice"] = tool_choice

        # Only keep BaseTool instances for self._tools to satisfy type checker
        self._tools = [tool for tool in tools if isinstance(tool, BaseTool)]
        self._formatted_tools = formatted_tools
        self._tool_choice = tool_choice

        system_message = "\n".join(
            [
                "You are a helpful assistant that can use tools to answer questions.",
                "You have access to the following tools:",
                str(formatted_tools),
                "To use a tool, call it with the appropriate parameters. like this:",
                "[TOOL_CALL]",
                "```json",
                '{"tool": "tool_name", "parameters": {"param1": "value1", "param2": "value2"}}',
                "```",
                'Always use tools when they are available and relevant to the question.',
                "If you don't need to use a tool, just answer the question directly.",
            ]
        )

        self.system_message = SystemMessage(content=system_message)

        return super().bind(tools=formatted_tools, **kwargs)

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Override the _generate method to implement the chat model logic.

        Args:
            messages: the prompt composed of a list of messages.
            stop: a list of strings on which the model should stop generating.
                  If generation stops due to a stop token, the stop token itself
                  SHOULD BE INCLUDED as part of the output. This is not enforced
                  across models right now, but it's a good practice to follow since
                  it makes it much easier to parse the output of the model
                  downstream and understand why generation stopped.
            run_manager: A run manager with callbacks for the LLM.
        """
        if not self.inetum_api:
            raise ValueError("InetumSDK instance could not be initialized.")

        # Prepare system prompt and conversation
        conversation = []
        system_prompt = None
        for message in messages:
            if isinstance(message, SystemMessage):
                system_prompt = (
                    str(message.content) + "\n\n" + str(self.system_message.content)
                    if self.system_message
                    else str(message.content)
                )
            else:
                conversation.append(f"{message.type}: {message.content}")

        user_prompt = (
            "\n---\n".join(conversation) if conversation else str(messages[0].content)
        )

        start_time = time.time()
        response_text = self.inetum_api.generate(
            user_prompt,
            system_prompt,
            timeout=self.timeout,
            stop=stop,
            polling_interval=self.polling_interval,
            **kwargs,
        )
        generation_time = time.time() - start_time

        # Token counting (simple char count, replace with tokenizer if needed)
        ct_input_tokens = sum(len(str(message.content)) for message in messages)
        ct_output_tokens = len(str(response_text))

        tool_calls = []

        # Tool call handling
        if "[TOOL_CALL]" in response_text:
            content = response_text.replace("[TOOL_CALL]", "").strip()
            content = JsonOutputParser().parse(content)
            selected_tool = content.get("tool")
            arguments = content.get("parameters", {})

            tool = None
            if self._formatted_tools and self._tools:
                for idx, t in enumerate(self._formatted_tools):
                    tool_name = t.get("function", {}).get("name") or t.get("name")
                    if tool_name == selected_tool:
                        tool = self._tools[idx]
                        break

            if tool is None:
                raise ValueError(f"Tool '{selected_tool}' not found among bound tools.")

            tool_calls.append(
                ToolCall(
                    id=f"tool_call_{int(time.time() * 1000)}",
                    name=tool.name,
                    args=arguments,
                )
            )
            response_text = ""

        response_metadata = {
            "time_in_seconds": generation_time,
            "model_name": self.model_name,
        }
        usage_metadata = {
            "input_tokens": ct_input_tokens,
            "output_tokens": ct_output_tokens,
            "total_tokens": ct_input_tokens + ct_output_tokens,
        }

        message = AIMessage(
            content=response_text,
            tool_calls=tool_calls,
            additional_kwargs={},
            response_metadata=response_metadata,
            usage_metadata=usage_metadata,
        )

        return ChatResult(generations=[ChatGeneration(message=message)])

    def _stream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> Iterator[ChatGenerationChunk]:
        """Override the _stream method to implement the chat model logic."""
        raise NotImplementedError("Streaming is not supported yet.")

    def _format_messages(self, messages: List[BaseMessage]) -> List[Dict[str, Any]]:
        """Formats the messages for the API request.

        Args:
            messages (List[BaseMessage]): List of messages to format.

        Returns:
            List[Dict[str, Any]]: The formatted messages.
        """
        formatted_messages = []
        for message in messages:
            if isinstance(message, HumanMessage):
                formatted_messages.append({"role": "user", "content": message.content})
            elif isinstance(message, AIMessage):
                formatted_messages.append(
                    {"role": "assistant", "content": message.content}
                )
            elif isinstance(message, SystemMessage):
                formatted_messages.append(
                    {"role": "system", "content": message.content}
                )
            elif isinstance(message, ToolMessage):
                formatted_messages.append(
                    {
                        "role": "tool",
                        "name": message.name,
                        "content": message.content,
                    }
                )
            else:
                raise ValueError(f"Unsupported message type: {type(message)}")
        return formatted_messages

    @property
    def _llm_type(self) -> str:
        return "inetum-chat-generation"

    @property
    def _identifying_params(self) -> Dict[str, Any]:
        """Return a dictionary of identifying parameters.

        This information is used by the LangChain callback system, which
        is used for tracing purposes make it possible to monitor LLMs.
        """
        return {
            "model_name": self.model_name,
        }
